﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Music_Service
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonConnect_Click(object sender, EventArgs e)
        {
            Buff.ServerBuffer = textBoxServer.Text;
            Buff.LoginBuffer = textBoxLogin.Text;
            Buff.PasswordBuffer = textBoxPassword.Text;
            Buff.DatabaseBuffer = textBoxDB.Text;
            this.Close();
            
        }
    }
}
