﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Music_Service
{
    public static class Buff
    {
        public delegate void ValueChangedEventHandler(object sender, EventArgs e);
        public static event ValueChangedEventHandler ValueChanged;
        public static String ServerBufferName = String.Empty;
        public static String LoginBufferName = String.Empty;
        public static String PasswordBufferName = String.Empty;
        public static String DatabaseBufferName = String.Empty;

        public static String ServerBuffer
        {
            get { return ServerBufferName; }
            set
            {
                ServerBufferName = value;
                ValueChanged(null, EventArgs.Empty);
            }
        }

        public static String LoginBuffer
        {
            get { return LoginBufferName; }
            set
            {
                LoginBufferName = value;
                ValueChanged(null, EventArgs.Empty);
            }
        }

        public static String PasswordBuffer
        {
            get { return PasswordBufferName; }
            set
            {
                PasswordBufferName = value;
                ValueChanged(null, EventArgs.Empty);
            }
        }

        public static String DatabaseBuffer
        {
            get { return DatabaseBufferName; }
            set
            {
                DatabaseBufferName = value;
                ValueChanged(null, EventArgs.Empty);
            }
        }
    }
}
