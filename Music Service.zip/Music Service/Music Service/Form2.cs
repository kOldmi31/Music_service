﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace Music_Service
{
    public partial class Form2 : Form
    {
        private DataSet dataset = new DataSet();
        private DataTable datatable = new DataTable();
        public Form2()
        {
            InitializeComponent();
            buttonConnect.Enabled = false;
            label1.Text = "Сервер: ";
            label2.Text = "База данных: ";
            label3.Text = "Пользователь: ";
            label4.Text = "Пароль: ";
        }

        private void buttonSettings_Click(object sender, EventArgs e)
        {
            Buff.ValueChanged += (object sender1, EventArgs e1) =>
            {
                label1.Text = "Адрес сервера: " + Buff.ServerBuffer;
                label2.Text = "База данных: " + Buff.DatabaseBuffer;
                label3.Text = "Пользователь: " + Buff.LoginBuffer;
                label4.Text = "Пароль: " + Buff.PasswordBuffer;
                buttonConnect.Enabled = true;
            };
            Form1 forma = new Form1();
            forma.ShowDialog();
        }

        private void buttonConnect_Click(object sender, EventArgs e)
        {
            var connString = "Host=" + Buff.ServerBuffer +
            ";UserName=" + Buff.LoginBuffer +
            ";Password=" + Buff.PasswordBuffer +
            ";Database=" + Buff.DatabaseBuffer;

            try
            {
                using (NpgsqlConnection connection = new NpgsqlConnection(connString))
                {
                    connection.Open();

                    NpgsqlCommand comand = new NpgsqlCommand("SELECT publick.\"Track\"()", connection);
                    NpgsqlDataReader dreader = comand.ExecuteReader();
                    if (dreader.Read())
                    {
                        label5.Text = dreader.GetString(0);
                        buttonStatus.BackColor = Color.Green;
                    }
                    else
                    {
                        label5.Text = "Connection - Error";
                        buttonStatus.BackColor = Color.Red;
                    }
                    dreader.Close();
                }
            }
            catch (Exception)
            {
                label5.Text = "Connection - Error";
                buttonStatus.BackColor = Color.Red;
            }
        }

        private void buttonInsert_Click(object sender, EventArgs e)
        {
            var connString = "Host=" + Buff.ServerBuffer +
            ";UserName=" + Buff.LoginBuffer +
            ";Password=" + Buff.PasswordBuffer +
            ";Database=" + Buff.DatabaseBuffer;
 
            using (NpgsqlConnection connection = new NpgsqlConnection(connString))
            {
                connection.Open();
                NpgsqlCommand comand = new NpgsqlCommand();
                comand.Connection = connection;
                comand.CommandText = $"INSERT INTO public.\"Artist\"(\"ArtistId\", \"Name\") VALUES (@value1, @value2)";
                var paramValue1 = comand.Parameters.Add("value1", NpgsqlTypes.NpgsqlDbType.Integer);
                var paramValue2 = comand.Parameters.Add("value2", NpgsqlTypes.NpgsqlDbType.Char);
                comand.Prepare();
                paramValue1.Value = 276;
                paramValue2.Value = "Bastille group";
                comand.ExecuteNonQuery();
                buttonStatus.BackColor = Color.Green;
                label5.Text = "OK";
                connection.Close();
            }
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            var connString = "Host=" + Buff.ServerBuffer +
            ";UserName=" + Buff.LoginBuffer +
            ";Password=" + Buff.PasswordBuffer +
            ";Database=" + Buff.DatabaseBuffer;

            using (NpgsqlConnection connection = new NpgsqlConnection(connString))
            {
                connection.Open();
                NpgsqlCommand comand = new NpgsqlCommand();
                comand.Connection = connection;
                comand.CommandText = $"DELETE FROM public.\"Artist\" WHERE \"ArtistId\" = @value";
                var paramValue = comand.Parameters.Add("value", NpgsqlTypes.NpgsqlDbType.Integer);
                comand.Prepare();
                paramValue.Value = 276;
                comand.ExecuteNonQuery();
                buttonStatus.BackColor = Color.Green;
                label5.Text = "OK";
                connection.Close();

            }
        }

        private void buttonSelectAll_Click(object sender, EventArgs e)
        {
            var connString = "Host=" + Buff.ServerBuffer +
            ";UserName=" + Buff.LoginBuffer +
            ";Password=" + Buff.PasswordBuffer +
            ";Database=" + Buff.DatabaseBuffer;

            using (NpgsqlConnection connection = new NpgsqlConnection(connString))
            {
                connection.Open();
                string query = ("SELECT * FROM " + comboBox1.SelectedItem);
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(query, connection);
                dataset.Reset();
                adapter.Fill(dataset);
                datatable = dataset.Tables[0];
                dataGridView1.DataSource = datatable;
                buttonStatus.BackColor = Color.Green;
                label5.Text = "OK";
                connection.Close();
            }
        }

        private void buttonSelect_Click(object sender, EventArgs e)
        {
            var connString = "Host=" + Buff.ServerBuffer +
            ";UserName=" + Buff.LoginBuffer +
            ";Password=" + Buff.PasswordBuffer +
            ";Database=" + Buff.DatabaseBuffer;

            try
            {
                using (NpgsqlConnection connection = new NpgsqlConnection(connString))
                {
                    connection.Open();
                    string query = ("SELECT * FROM public.\"Artist\" WHERE \"ArtistId\"=" + textBoxID.Text);
                    NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(query, connection);
                    dataset.Reset();
                    adapter.Fill(dataset);
                    datatable = dataset.Tables[0];
                    dataGridView1.DataSource = datatable;
                    buttonStatus.BackColor = Color.Green;
                    label5.Text = "OK";
                    connection.Close();
                }
            }
            catch (Exception)
            {
                label5.Text = "Error";
                buttonStatus.BackColor = Color.Red;
                MessageBox.Show("Нет записи с таким ID");
            }
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            var connString = "Host=" + Buff.ServerBuffer +
            ";UserName=" + Buff.LoginBuffer +
            ";Password=" + Buff.PasswordBuffer +
            ";Database=" + Buff.DatabaseBuffer;

            using (NpgsqlConnection connection = new NpgsqlConnection(connString))
            {
                connection.Open();
                NpgsqlCommand comand = new NpgsqlCommand();
                comand.Connection = connection;
                comand.CommandText = $"UPDATE public.\"Artist\" SET \"Name\" = @value WHERE \"ArtistId\"=" + textBoxID.Text;
                var paramValue = comand.Parameters.Add("value", NpgsqlTypes.NpgsqlDbType.Char);
                comand.Prepare();
                paramValue.Value = textBoxArtistName.Text;
                comand.ExecuteNonQuery();
                buttonStatus.BackColor = Color.Green;
                label5.Text = "OK";
                connection.Close();
            }
        }
    }
}
